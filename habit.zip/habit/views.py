from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

from .models import Habit, HabitLog
from django.contrib.auth.models import User


@api_view(['post'])
def log_habit_value(request):
    try:
        habit_id = request.data.get('habit_id')
        user_id = request.data.get('user_id')
        value = request.data.get('value')
        date = request.data.get('date')

        habit = get_object_or_404(Habit, id=habit_id)
        user = get_object_or_404(User, id=user_id)

        HabitLog.objects.create(
            habit=habit,
            user=user,
            value=value,
            date=date
        )

        return Response({'message': 'Habit log saved successfully.'}, status=status.HTTP_201_CREATED)

    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['get'])
def get_user_average_habit_value(request, user_id):
    try:
        user = get_object_or_404(User, id=user_id)
        logs = HabitLog.objects.filter(user=user)

        if not logs.exists():
            return Response({'message': 'No logs found for user.'}, status=status.HTTP_404_NOT_FOUND)

        averages = {}
        for habit in logs.values_list('habit', flat=True).distinct():
            habit_logs = logs.filter(habit_id=habit)
            habit_name = habit_logs.first().habit.name
            try:
                values = [float(log.value) for log in habit_logs]
                average = sum(values) / len(values)
                averages[habit_name] = round(average, 2)
            except ValueError:
                averages[habit_name] = 'Non-numeric values cannot be averaged.'

        return Response({'averages': averages}, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
