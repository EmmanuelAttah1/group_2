from django.urls import path
from . import views

urlpatterns = [
    path('log/', views.log_habit_value, name='log_habit_value'),
    path('<int:user_id>/average/', views.get_user_average_habit_value, name='get_user_average'),
]
